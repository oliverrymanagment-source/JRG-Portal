const $ = (s, r=document) => r.querySelector(s);
const setText = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
setText('year', new Date().getFullYear());
setText('today', new Intl.DateTimeFormat('pl-PL',{day:'2-digit',month:'long',year:'numeric'}).format(new Date()));
const toggle = $('.menu-toggle'), nav = $('.nav');
if (toggle && nav) toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));});
const dateLabel = d => new Intl.DateTimeFormat('pl-PL',{day:'2-digit',month:'long',year:'numeric'}).format(new Date(d+'T12:00:00'));
function newsCard(item){return `<article class="news-card"><div class="news-meta"><span>${item.category}</span><time>${dateLabel(item.date)}</time></div><h3>${item.title}</h3><p>${item.excerpt}</p><a class="arrow-link" href="${item.url}">Czytaj więcej <span>↗</span></a></article>`;}
fetch('data/news.json').then(r=>r.json()).then(items=>{
 const home=$('#home-news'), all=$('#all-news'), search=$('#news-search'), count=$('#news-count');
 if(home) home.innerHTML=items.slice(0,3).map(newsCard).join('');
 const render=()=>{if(!all)return;const q=(search?.value||'').toLocaleLowerCase('pl');const filtered=items.filter(x=>(x.title+' '+x.excerpt+' '+x.category).toLocaleLowerCase('pl').includes(q));all.innerHTML=filtered.length?filtered.map(newsCard).join(''):'<p class="notice">Nie znaleziono pasujących aktualności.</p>';if(count)count.textContent=`${filtered.length} / ${items.length} WPISÓW`;};
 if(all){render();search?.addEventListener('input',render);}
}).catch(()=>{});
fetch('data/vehicles.json').then(r=>r.json()).then(items=>{
 const list=$('#vehicle-list'), search=$('#vehicle-search');if(!list)return;
 const render=()=>{const q=(search?.value||'').toLocaleLowerCase('pl');const filtered=items.filter(x=>(x.number+x.name+x.type+x.description).toLocaleLowerCase('pl').includes(q));list.innerHTML=filtered.length?filtered.map(x=>`<article class="vehicle-card"><div class="vehicle-image">${x.image?`<img src="${x.image}" alt="${x.name}">`:'<span>FOTOGRAFIA POJAZDU</span>'}</div><div class="vehicle-info"><span class="eyebrow">${x.type} / ${x.number}</span><h3>${x.name}</h3><p>${x.description}</p></div></article>`).join(''):'<p class="notice">Nie znaleziono pojazdów.</p>';};
 render();search?.addEventListener('input',render);
}).catch(()=>{});
