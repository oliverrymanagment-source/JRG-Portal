# JRG Portal — wersja startowa

Autorski, statyczny szablon portalu informacyjnego jednostki ratowniczo-gaśniczej.

## Uruchomienie
Otwórz `index.html` w przeglądarce. Aby pobieranie plików JSON działało poprawnie lokalnie, uruchom folder przez prosty serwer (np. rozszerzenie Live Server w VS Code) albo opublikuj repozytorium na GitHub Pages.

## Edycja
- Nazwa jednostki i teksty: pliki HTML.
- Kolory, układ, typografia: `css/style.css`.
- Aktualności: `data/news.json`.
- Pojazdy: `data/vehicles.json`.
- Zdjęcia: podmień adresy w `css/style.css` i dodaj własne zdjęcia w `assets/images/`.

## Ważne
To nieoficjalny projekt demonstracyjny. Nie używa oficjalnego herbu ani nie sugeruje, że jest autoryzowany przez PSP. Przed publikacją uzupełnij dane i używaj wyłącznie materiałów, do których masz prawa oraz zgody.
